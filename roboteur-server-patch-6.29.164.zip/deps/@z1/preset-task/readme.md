# Z1 Preset Task

Documentation under construction.

## Usage

Install

```
yarn add @z1/preset-task
```

# Z1 Kit Account Server

Documentation under construction.

## Usage

Install

```
yarn add @z1/kit-account-server
```

Import

```JavaScript

import * from '@z1/kit-account-server'

```

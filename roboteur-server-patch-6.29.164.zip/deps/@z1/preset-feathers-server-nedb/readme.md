# Z1 Preset Feathers Server Nedb

Documentation under construction.

## Usage

Install

```
yarn add @z1/preset-feathers-server-nedb
```

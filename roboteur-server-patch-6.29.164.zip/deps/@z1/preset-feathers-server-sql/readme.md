# Z1 Preset Feathers Server SQL

Documentation under construction.

## Usage

Install

```
yarn add @z1/preset-feathers-server-sql
```


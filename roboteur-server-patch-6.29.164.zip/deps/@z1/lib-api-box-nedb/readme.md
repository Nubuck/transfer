# Z1 Lib Api Box Nedb

Documentation under construction.

## Usage

Install

```
yarn add @z1/lib-api-box-nedb
```

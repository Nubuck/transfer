# Z1 Kit Machine Account Server

Documentation under construction.

## Usage

Install

```
yarn add @z1/kit-machine-account-server
```

Import

```JavaScript

import * from '@z1/kit-machine-account-server'

```

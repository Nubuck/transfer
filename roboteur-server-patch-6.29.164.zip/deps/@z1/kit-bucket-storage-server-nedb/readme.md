# Z1 Kit Bucket Storage Server Nedb

Documentation under construction.

## Usage

Install

```
yarn add @z1/kit-bucket-storage-server-nedb
```

Import

```JavaScript

import * from '@z1/kit-bucket-storage-server-nedb'

```

# Z1 Preset Tools

Documentation under construction.

## Usage

Install

```
yarn add @z1/preset-tools
```

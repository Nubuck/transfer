# Z1 Preset Feathers Server Core

Documentation under construction.

## Usage

Install

```
yarn add @z1/preset-feathers-server
```

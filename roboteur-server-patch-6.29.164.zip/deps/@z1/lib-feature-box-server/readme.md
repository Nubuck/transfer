# Z1 Lib Feature Box Server

Documentation under construction.

## Usage

Install

```
yarn add @z1/lib-feature-box-server
```


# Z1 Kit Machine Account Server Nedb

Documentation under construction.

## Usage

Install

```
yarn add @z1/kit-machine-account-server-nedb
```

Import

```JavaScript

import * from '@z1/kit-machine-account-server-nedb'

```

# Z1 Kit Account Server Core

Documentation under construction.

## Usage

Install

```
yarn add @z1/kit-account-server-core
```

Import

```JavaScript

import * from '@z1/kit-account-server-core'

```
